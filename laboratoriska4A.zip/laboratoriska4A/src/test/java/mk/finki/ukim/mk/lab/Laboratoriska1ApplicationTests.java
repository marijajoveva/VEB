package mk.finki.ukim.mk.lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Laboratoriska1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
